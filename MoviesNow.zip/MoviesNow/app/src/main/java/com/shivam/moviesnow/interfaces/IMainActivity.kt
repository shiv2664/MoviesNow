package com.shivam.moviesnow.interfaces

interface IMainActivity {
}